package de.todo42.adesso.book;

public enum ErrorCodes {
    WRONG_TITLE

}
