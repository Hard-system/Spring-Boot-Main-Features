package de.todo42.adesso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdessoApplication {
   
	public static void main(String[] args) {
		SpringApplication.run(AdessoApplication.class, args);
	}

}
