INSERT INTO books (title, author, isbn) VALUES ('Spring Boot 2', 'Michael Simons','978-3864905254');
INSERT INTO books (title, author, isbn) VALUES ('Clean Code', 'Robert C. Martin','978-0132350884');
INSERT INTO books (title, author, isbn) VALUES ('Design Pattern', 'E. Gamma, R. Helm, R. Johnson, J. Vlissides','978-3-86490-525-4');